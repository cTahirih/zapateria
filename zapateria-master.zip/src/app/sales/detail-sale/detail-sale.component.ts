import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detail-sale',
  templateUrl: './detail-sale.component.html',
  styleUrls: ['./detail-sale.component.scss']
})
export class DetailSaleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
